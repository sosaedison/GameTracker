from MainView import MainView

if __name__ == "__main__":
    app = MainView()
    app.mainloop()